/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itam.com111020_02.colecciones;

import java.util.Set;

/**
 *
 * @author GuillermoNaranjo
 */
public interface Conjunto<E> extends Set<E> {
    
    
    
}
