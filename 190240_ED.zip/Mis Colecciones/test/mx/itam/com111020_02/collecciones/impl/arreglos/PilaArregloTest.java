/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.itam.com111020_02.collecciones.impl.arreglos;

import java.util.Collection;
import java.util.Iterator;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.fail;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author GuillermoNaranjo
 */
public class PilaArregloTest {
    
    public PilaArregloTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of push method, of class PilaArreglo.
     */
    @Test
    public void testPush() {
        System.out.println("push");
        Object nuevoElemento = null;
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = true;
        boolean result = instance.push(nuevoElemento);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of pop method, of class PilaArreglo.
     */
    @Test
    public void testPop() {
        System.out.println("pop");
        PilaArreglo instance = new PilaArreglo();
        instance.push("Cabeza");
        Object result=instance.pop();
        assertEquals("Cabeza", result);
        
    }

    /**
     * Test of peek method, of class PilaArreglo.
     */
    @Test
    public void testPeek() {
        System.out.println("peek");
        PilaArreglo instance = new PilaArreglo();
        Object expResult = null;
        Object result = instance.peek();
        assertEquals(expResult, result);
        
        expResult=("CadenaPrueba");
        instance.push(expResult);
        result=instance.peek();
        assertEquals(expResult, result);
        result =instance.pop();
        assertEquals(expResult, result);
    }

    /**
     * Test of size method, of class PilaArreglo.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        PilaArreglo instance = new PilaArreglo(100);
        int expResult = 0;
        int result = instance.size();
        assertEquals(expResult, result);
        
        for(int i=0; i<50; i++)
            instance.push(i);
        assertEquals("50", "50");
        
    }

    /**
     * Test of isEmpty method, of class PilaArreglo.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = false;
        boolean result = instance.isEmpty();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of contains method, of class PilaArreglo.
     */
    @Test
    public void testContains() {
        System.out.println("contains");
        Object o = null;
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = false;
        boolean result = instance.contains(o);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of iterator method, of class PilaArreglo.
     */
    @Test
    public void testIterator() {
        int cuantos=10, cont=9; 
        
        System.out.println("iterator");
        PilaArreglo instance = new PilaArreglo();
        Iterator expResult = null;
        Iterator result = instance.iterator();
        
        for(int i=0; i<cuantos; i++)
            instance.push(Integer.toString(i));
        for(Object s: instance){
             if(!Integer.toString(cont).equals(s))
                fail("el iterador no pasa por el elemento "+cont);
             
             if(cont>0)
                 --cont;
        }
        assertEquals(0, cont);
    }

    /**
     * Test of toArray method, of class PilaArreglo.
     */
//    @Test
//    public void testToArray_0args() {
//        System.out.println("toArray");
//        PilaArreglo instance = new PilaArreglo();
//        Object[] expResult = null;
//        Object[] result = instance.toArray();
//        assertArrayEquals(expResult, result);
//        
//    }

    /**
     * Test of toArray method, of class PilaArreglo.
     */
//    @Test
//    public void testToArray_GenericType() {
//        System.out.println("toArray");
//        Object[] a = null;
//        PilaArreglo instance = new PilaArreglo();
//        Object[] expResult = null;
//        Object[] result = instance.toArray(a);
//        assertArrayEquals(expResult, result);
//        
//    }

    /**
     * Test of add method, of class PilaArreglo.
     */
//    @Test
//    public void testAdd() {
//        System.out.println("add");
//        Object e = null;
//        PilaArreglo instance = new PilaArreglo();
//        boolean expResult = false;
//        boolean result = instance.add(e);
//        assertEquals(expResult, result);
//        
//    }

    /**
     * Test of remove method, of class PilaArreglo.
     */
//    @Test
//    public void testRemove() {
//        System.out.println("remove");
//        Object o = null;
//        PilaArreglo instance = new PilaArreglo();
//        boolean expResult = false;
//        boolean result = instance.remove(o);
//        assertEquals(expResult, result);
//        
//    }

    /**
     * Test of containsAll method, of class PilaArreglo.
     */
    @Test
    public void testContainsAll() {
        System.out.println("containsAll");
        Collection c = null;
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = false;
        boolean result = instance.containsAll(c);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of addAll method, of class PilaArreglo.
     */
    @Test
    public void testAddAll() {
        System.out.println("addAll");
        Collection c = null;
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = false;
        boolean result = instance.addAll(c);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of removeAll method, of class PilaArreglo.
     */
//    @Test
//    public void testRemoveAll() {
//        System.out.println("removeAll");
//        Collection c = null;
//        PilaArreglo instance = new PilaArreglo();
//        boolean expResult = false;
//        boolean result = instance.removeAll(c);
//        assertEquals(expResult, result);
//        
//    }

    /**
     * Test of retainAll method, of class PilaArreglo.
     */
//    @Test
//    public void testRetainAll() {
//        System.out.println("retainAll");
//        Collection c = null;
//        PilaArreglo instance = new PilaArreglo();
//        boolean expResult = false;
//        boolean result = instance.retainAll(c);
//        assertEquals(expResult, result);
//        
//    }

    /**
     * Test of clear method, of class PilaArreglo.
     */
//    @Test
//    public void testClear() {
//        System.out.println("clear");
//        PilaArreglo instance = new PilaArreglo();
//        instance.clear();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of equals method, of class PilaArreglo.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object o = null;
        PilaArreglo instance = new PilaArreglo();
        boolean expResult = false;
        boolean result = instance.equals(o);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of hashCode method, of class PilaArreglo.
     */
//    @Test
//    public void testHashCode() {
//        System.out.println("hashCode");
//        PilaArreglo instance = new PilaArreglo();
//        int expResult = 0;
//        int result = instance.hashCode();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of invierte method, of class PilaArreglo.
     */
//    @Test
//    public void testInvierte() {
//        System.out.println("invierte");
//        Object[] a = null;
//        PilaArreglo instance = new PilaArreglo();
//        instance.invierte(a);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
